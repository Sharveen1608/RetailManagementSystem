package Retail.demo.solution;


public class Admin {
     
    private String Username;
    
    public Admin(){
    super();
    }
    
    public void setUsername(String Username)
    {
        this.Username = Username;
    }
    public String getUsername()
    {
        return Username;
    } 
     private String password;
    
    public void setPassword(String password)
    {
        this.password = password;
    }
    public String getPassword()
    {
        return password;
    } 
  

        }


