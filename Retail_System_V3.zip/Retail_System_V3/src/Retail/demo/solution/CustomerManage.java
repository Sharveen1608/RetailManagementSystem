/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Retail.demo.solution;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Acer
 */
public class CustomerManage {
    
    String file = "Customer.txt";
    String login = "CustomerLogin.txt";
    
    public int AddCustomer(CustomerEntity customerEntity)
    {
        Boolean isCustomerAdded = false;

        int CustomerIndex = GetLastIndex() + 1500 ;
        try
        {
            FileWriter fw = new FileWriter(file,true);
            fw.write(CustomerIndex + ","+ customerEntity.getCustomerName() + "," +customerEntity.getEmail() + "," +customerEntity.getAddress()+ ","+customerEntity.getPhone()+","+customerEntity.getPassword()+System.getProperty("line.separator"));
            fw.close();
            isCustomerAdded = true;
        }
        catch (IOException ex)
        {
            isCustomerAdded = false;
        }
        catch (Exception ex)
        {
            isCustomerAdded = false;
        }
        return CustomerIndex;
    }
    
    public int AddCustomerLogin(CustomerEntity customerEntity)
    {
        Boolean isLoginAdded = false;
        int CustomerIndex = GetLastIndex() + 1;
        try
        {
           FileWriter fw = new FileWriter(login,true);
           fw.write(customerEntity.getCustomerName() + "," +customerEntity.getPassword()+System.getProperty("line.separator"));
           fw.close();
           isLoginAdded = true;
        }
        catch (IOException ex){
            isLoginAdded = false;
        }
        catch (Exception ex)
        {
            isLoginAdded = false;
        }
        return CustomerIndex;
    }
    
    public Boolean DeleteCustomer(int CustomerID){
        Boolean isDeleted = false;
        try{
            String fileContent = "";
            Path path = Paths.get(file);
            byte[] bytes = Files.readAllBytes(path);
            List<String> allLines = Files.readAllLines(path, StandardCharsets.UTF_8);
            for (String data : allLines){
                if(!data.equals("")){
                    String[] arrOfStr = data.split(",");
                    if (Integer.parseInt(arrOfStr[0])== CustomerID){
                        
                    }else{
                        fileContent = fileContent + (arrOfStr[0]+","+arrOfStr[1]+","+arrOfStr[2]+","+arrOfStr[3]+","+arrOfStr[4]+","+arrOfStr[5]+System.getProperty("line.separator"));
                    }
            }
        }
        File file1 = new File(file);
        file1.delete();
        file1.createNewFile();
        FileWriter fw = new FileWriter(file,true);
        fw.write(fileContent);
        fw.close();
        isDeleted = true;
    }catch (IOException ex){
        isDeleted = false;
    }
        return isDeleted;
    }
    
    public Boolean DeleteLogin(String CustomerName){
        Boolean isDeleted = false;
        try{
            String fileContent = "";
            Path path = Paths.get(login);
            byte[] bytes = Files.readAllBytes(path);
            List<String> allLines = Files.readAllLines(path, StandardCharsets.UTF_8);
            for (String data : allLines){
                if(!data.equals("")){
                    String[] arrOfStr = data.split(",");
                    if (arrOfStr[0].equals(CustomerName)){
                        
                    }else{
                        fileContent = fileContent + (arrOfStr[0]+","+arrOfStr[1]+ System.getProperty("line.separator"));
                    }
            }
        }
        File file1 = new File(login);
        file1.delete();
        file1.createNewFile();
        FileWriter fw = new FileWriter(login,true);
        fw.write(fileContent);
        fw.close();
        isDeleted = true;
    }catch (IOException ex){
        isDeleted = false;
    }
        return isDeleted;
    }
    
    public List<CustomerEntity> GetCustomerByName(String CustomerName) throws IOException {
         List<CustomerEntity> target = new ArrayList<>();
        Path path = Paths.get(file);
        byte[] bytes = Files.readAllBytes(path);
        List<String> allLines = Files.readAllLines(path, StandardCharsets.UTF_8);
        for (String searchData : allLines) {
            if (!searchData.equals("")) {
                String[] arrOfStr = searchData.split(",");
                CustomerEntity customerEntity =new CustomerEntity();
                if (arrOfStr[1].equals(CustomerName)) {
                    customerEntity.setCustomerID(Integer.parseInt(arrOfStr[0]));
                    customerEntity.setCustomerName(arrOfStr[1]);
                    customerEntity.setEmail(arrOfStr[2]);
                    customerEntity.setAddress(arrOfStr[3]);
                    customerEntity.setPhone(arrOfStr[4]);
                    customerEntity.setPassword(arrOfStr[5]);
                    target.add(customerEntity);
                }
            }
        }
        return target;
    }
    
//    public CustomerEntity search(String name){
//        
//        CustomerEntity target = new CustomerEntity();
//        
//        //logic code - getall record from the datafile and find the targeted customer by name
//        return target;
//    }
    
    public Boolean UpdateCustomer(CustomerEntity customerEntity) {
        Boolean isUpdated = false;
        try {
            String Content = "";
            Path path = Paths.get(file);
            byte[] bytes = Files.readAllBytes(path);
            List<String> allLines = Files.readAllLines(path, StandardCharsets.UTF_8);
            for (String data : allLines) {
                if (!data.equals("")) {
                    String[] arrOfStr = data.split(",");
                    if (Integer.parseInt(arrOfStr[0]) == customerEntity.getCustomerID()) {
                        Content = Content + (customerEntity.getCustomerID() + "," + customerEntity.getCustomerName() + "," + customerEntity.getEmail() + "," + customerEntity.getAddress() + "," + customerEntity.getPhone() + "," + customerEntity.getPassword()+System.getProperty("line.separator"));
                    } else {
                        Content = Content + (arrOfStr[0] + "," + arrOfStr[1] + "," + arrOfStr[2] + "," + arrOfStr[3] + "," + arrOfStr[4] + "," + arrOfStr[5] + System.getProperty("line.separator"));
                    }
                }
            }
            File file1 = new File(file);
            file1.delete();
            file1.createNewFile();
            FileWriter fw = new FileWriter(file, true);
            fw.write(Content);
            fw.close();
            isUpdated = true;
        } catch (IOException ex) {
            isUpdated = false;
        }
        return isUpdated;
    }
    
    public Boolean UpdateLogin(CustomerEntity customerEntity) {
        Boolean isUpdated = false;
        try {
            String Content = "";
            Path path = Paths.get(login);
            byte[] bytes = Files.readAllBytes(path);
            List<String> allLines = Files.readAllLines(path, StandardCharsets.UTF_8);
            for (String data : allLines) {
                if (!data.equals("")) {
                    String[] arrOfStr = data.split(",");
                    if (arrOfStr[0].equals(customerEntity.getCustomerName())) {
                        Content = Content + (customerEntity.getCustomerName() + "," + customerEntity.getPassword()+System.getProperty("line.separator"));
                    } else {
                        Content = Content + (arrOfStr[0] + "," + arrOfStr[1] + System.getProperty("line.separator"));
                    }
                }
            }
            File file1 = new File(login);
            file1.delete();
            file1.createNewFile();
            FileWriter fw = new FileWriter(login, true);
            fw.write(Content);
            fw.close();
            isUpdated = true;
        } catch (IOException ex) {
            isUpdated = false;
        }
        return isUpdated;
    }
    public List<CustomerEntity> GetCustomer() throws IOException {
        List<CustomerEntity> lstCustomer = new ArrayList<>();
        Path path = Paths.get(file);
        byte[] bytes = Files.readAllBytes(path);
        List<String> allLines = Files.readAllLines(path, StandardCharsets.UTF_8);
        for (String customerData : allLines) {
            if (!customerData.equals("")) {
                String[] arrOfStr = customerData.split(",");
                CustomerEntity customerEntity = new CustomerEntity();
                customerEntity.setCustomerID(Integer.parseInt(arrOfStr[0]));
                customerEntity.setCustomerName(arrOfStr[1]);
                customerEntity.setEmail(arrOfStr[2]);
                customerEntity.setAddress(arrOfStr[3]);
                customerEntity.setPhone(arrOfStr[4]);
                customerEntity.setPassword(arrOfStr[5]);
                lstCustomer.add(customerEntity);
            }
        }
        return lstCustomer;
    }

        public int GetLastIndex() {
        int lastID = 55;
        if (isDataExists()) {
            try {
                Path path = Paths.get(file);
                byte[] bytes = Files.readAllBytes(path);
                List<String> allLines = Files.readAllLines(path, StandardCharsets.UTF_8);
                String[] arrOfStr = allLines.get(allLines.size() - 1).split(",");
                lastID = Integer.parseInt(arrOfStr[0]);
            } catch (IOException ex) {
            }
        }
        return lastID;
    }

    public boolean isDataExists() {
        boolean isExists = false;
        try {
            Path path = Paths.get(file);
            byte[] bytes = Files.readAllBytes(path);
            List<String> allLines = Files.readAllLines(path, StandardCharsets.UTF_8);
            if (allLines.size() > 0 && !allLines.get(0).equals("")) {
                isExists = true;
            }
        } catch (IOException ex) {

        }
        return isExists;
    }
    
    
}
