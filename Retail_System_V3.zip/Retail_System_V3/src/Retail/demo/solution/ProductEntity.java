/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Retail.demo.solution;

/**
 *
 * @author Acer
 */
public class ProductEntity {
    private int ProductID;
    
    public void setProductID(int ProductID)
    {
        this.ProductID = ProductID;
    }
    public int getProductID()
    {
        return ProductID;
    } 
    
    private String ProductName;
    
    public void setProductName(String ProductName)
    {
        this.ProductName = ProductName;
    }
    public String getProductName()
    {
        return ProductName;
    } 
    
    private String Category;
    
    public void setCategory(String Category)
    {
        this.Category = Category;
    }
    public String getCategory()
    {
        return Category;
    }
    
    private int Cost;
    
    public void setCost(int Cost)
    {
        this.Cost = Cost;
    }
    public int getCost()
    {
        return Cost;
    }
    
    private int Price;
    
    public void setPrice(int Price)
    {
        this.Price = Price;
    }
    public int getPrice()
    {
        return Price;
    }
    
    private String Description;
    
    public void setDescription(String Description)
    {
        this.Description=Description;
    }
    public String getDescription()
    {
        return Description;
    }
}
