/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Retail.demo.solution;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Acer
 */
public class ProductManage {
    String fileName = "Product.txt";
    
    public int AddProduct(ProductEntity productEntity)
    {
        Boolean isProductAdded = false;
        int ProductIndex = GetLastIndex() + 1;
        try
        {
            FileWriter fw = new FileWriter(fileName,true);
            fw.write(ProductIndex + ","+ productEntity.getProductName() + "," +productEntity.getCategory() + "," +productEntity.getCost()+ ","+productEntity.getPrice()+","+productEntity.getDescription()+System.getProperty("line.separator"));
            fw.close();
            isProductAdded = true;
        }
        catch (IOException ex)
        {
            isProductAdded = false;
        }
        catch (Exception ex)
        {
            isProductAdded = false;
        }
        return ProductIndex;
    }
    
        public Boolean DeleteProduct(int ProductID){
        Boolean isDeleted = false;
        try{
            String fileContent = "";
            Path path = Paths.get(fileName);
            byte[] bytes = Files.readAllBytes(path);
            List<String> allLines = Files.readAllLines(path, StandardCharsets.UTF_8);
            for (String data : allLines){
                if(!data.equals("")){
                    String[] arrOfStr = data.split(",");
                    if (Integer.parseInt(arrOfStr[0])== ProductID){
                        
                    }else{
                        fileContent = fileContent + (arrOfStr[0]+","+arrOfStr[1]+","+arrOfStr[2]+","+arrOfStr[3]+","+arrOfStr[4]+","+arrOfStr[5]+System.getProperty("line.separator"));
                    }
            }
        }
        File file2 = new File(fileName);
        file2.delete();
        file2.createNewFile();
        FileWriter fw = new FileWriter(fileName,true);
        fw.write(fileContent);
        fw.close();
        isDeleted = true;
    }catch (IOException ex){
        isDeleted = false;
    }
        return isDeleted;
    }
        
     public Boolean UpdateProduct(ProductEntity productEntity) {
        Boolean isUpdated = false;
        try {
            String Content = "";
            Path path = Paths.get(fileName);
            byte[] bytes = Files.readAllBytes(path);
            List<String> allLines = Files.readAllLines(path, StandardCharsets.UTF_8);
            for (String data : allLines) {
                if (!data.equals("")) {
                    String[] arrOfStr = data.split(",");
                    if (Integer.parseInt(arrOfStr[0]) == productEntity.getProductID()) {
                        Content = Content + (productEntity.getProductID() + "," + productEntity.getProductName() + "," + productEntity.getCategory() + "," + productEntity.getCost() + "," + productEntity.getPrice() + "," + productEntity.getDescription()+System.getProperty("line.separator"));
                    } else {
                        Content = Content + (arrOfStr[0] + "," + arrOfStr[1] + "," + arrOfStr[2] + "," + arrOfStr[3] + "," + arrOfStr[4] + "," + arrOfStr[5] + System.getProperty("line.separator"));
                    }
                }
            }
            File file2 = new File(fileName);
            file2.delete();
            file2.createNewFile();
            FileWriter fw = new FileWriter(fileName, true);
            fw.write(Content);
            fw.close();
            isUpdated = true;
        } catch (IOException ex) {
            isUpdated = false;
        }
        return isUpdated;
    }
        
    public List<ProductEntity> GetProduct() throws IOException {
        List<ProductEntity> lstProduct = new ArrayList<>();
        Path path = Paths.get(fileName);
        byte[] bytes = Files.readAllBytes(path);
        List<String> allLines = Files.readAllLines(path, StandardCharsets.UTF_8);
        for (String productData : allLines) {
            if (!productData.equals("")) {
                String[] arrOfStr = productData.split(",");
                ProductEntity productEntity = new ProductEntity();
                productEntity.setProductID(Integer.parseInt(arrOfStr[0]));
                productEntity.setProductName(arrOfStr[1]);
                productEntity.setCategory(arrOfStr[2]);
                productEntity.setCost(Integer.parseInt(arrOfStr[3]));
                productEntity.setPrice(Integer.parseInt(arrOfStr[4]));
                productEntity.setDescription(arrOfStr[5]);
                lstProduct.add(productEntity);
            }
        }
        return lstProduct;
    }
    
     public List<ProductEntity> GetProductByName(String ProductName) throws IOException {
         List<ProductEntity> target = new ArrayList<>();
        Path path = Paths.get(fileName);
        byte[] bytes = Files.readAllBytes(path);
        List<String> allLines = Files.readAllLines(path, StandardCharsets.UTF_8);
        for (String searchData : allLines) {
            if (!searchData.equals("")) {
                String[] arrOfStr = searchData.split(",");
                ProductEntity productEntity =new ProductEntity();
                if (arrOfStr[1].equals(ProductName)) {
                    productEntity.setProductID(Integer.parseInt(arrOfStr[0]));
                    productEntity.setProductName(arrOfStr[1]);
                    productEntity.setCategory(arrOfStr[2]);
                    productEntity.setCost(Integer.parseInt(arrOfStr[3]));
                    productEntity.setPrice(Integer.parseInt(arrOfStr[4]));
                    productEntity.setDescription(arrOfStr[5]);
                    target.add(productEntity);
                }
            }
        }
        return target;
    }
        
    private int GetLastIndex() {
       int lastID = 0;
        if (isDataExists()) {
            try {
                Path path = Paths.get(fileName);
                byte[] bytes = Files.readAllBytes(path);
                List<String> allLines = Files.readAllLines(path, StandardCharsets.UTF_8);
                String[] arrOfStr = allLines.get(allLines.size() - 1).split(",");
                lastID = Integer.parseInt(arrOfStr[0]);
            } catch (IOException ex) {
            }
        }
        return lastID;
    }

    private boolean isDataExists() {
        boolean isExists = false;
        try {
            Path path = Paths.get(fileName);
            byte[] bytes = Files.readAllBytes(path);
            List<String> allLines = Files.readAllLines(path, StandardCharsets.UTF_8);
            if (allLines.size() > 0 && !allLines.get(0).equals("")) {
                isExists = true;
            }
        } catch (IOException ex) {

        }
        return isExists;
    }

    public List<ProductEntity> GetCustomerByName(String ProductName) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
