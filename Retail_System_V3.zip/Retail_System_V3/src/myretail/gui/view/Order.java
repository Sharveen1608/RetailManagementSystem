/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myretail.gui.view;

//import retailmanagementsystem.GUI.AdminCartManage;
import Retail.demo.solution.CustomerEntity;
import Retail.demo.solution.CustomerManage;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import Retail.demo.solution.OrderEntity;
import Retail.demo.solution.OrderOperation;
import Retail.demo.solution.ProductEntity;
import Retail.demo.solution.ProductManage;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;

//import Retail.demo.solution.CustomerManage;
//import Retail.demo.solution.CustomerEntity;
/**
 *
 * @author nitro 5
 */
public class Order extends javax.swing.JFrame {

    /**
     * Creates new form Order
     */
    public Order() throws IOException {
        initComponents();
        LoadCustomerData();
        LoadProductData();
    }
    CustomerManage customerManage = new CustomerManage();

    public void LoadCustomerData() throws IOException {

        try {
            DefaultTableModel CustomerTable = new DefaultTableModel();
            CustomerTable.addColumn("Customer ID");
            CustomerTable.addColumn("Name");
            CustomerTable.addColumn("Email");
            CustomerTable.addColumn("Address");
            CustomerTable.addColumn("Phone No");
            CustomerTable.addColumn("Password");
            List<CustomerEntity> allCustomer = customerManage.GetCustomer();
            for (CustomerEntity customerData : allCustomer) {
                CustomerTable.addRow(new Object[]{customerData.getCustomerID(), customerData.getCustomerName(), customerData.getEmail(), customerData.getAddress(), customerData.getPhone(), customerData.getPassword()});
            }
            this.CustomerTable.setModel(CustomerTable);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Fail to loading customer.", "Error", 0);
        }
    }

    ProductManage productManage = new ProductManage();

    public void LoadProductData() throws IOException {
        try {
            DefaultTableModel ProductTable = new DefaultTableModel();
            ProductTable.addColumn("Product ID");
            ProductTable.addColumn("Name");
            ProductTable.addColumn("Category");
            ProductTable.addColumn("Cost");
            ProductTable.addColumn("Price");
            ProductTable.addColumn("Description");
            List<ProductEntity> allProduct = productManage.GetProduct();
            for (ProductEntity productData : allProduct) {
                ProductTable.addRow(new Object[]{productData.getProductID(), productData.getProductName(), productData.getCategory(), productData.getCost(), productData.getPrice(), productData.getDescription()});
            }
            this.ProductTable.setModel(ProductTable);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Fail to loading product.", "Error", 0);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton5 = new javax.swing.JButton();
        jTextField7 = new javax.swing.JTextField();
        txtCustomer_ID = new javax.swing.JTextField();
        txtProduct_Name = new javax.swing.JTextField();
        txt_Quantity = new javax.swing.JTextField();
        btnAddCart = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtProductPrice = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtTotalPrice = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        btnSearchCustomer = new javax.swing.JButton();
        txtCustomerName = new javax.swing.JTextField();
        btnSearchProduct = new javax.swing.JButton();
        txtProductName = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        CustomerTable = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        ProductTable = new javax.swing.JTable();
        btnReloadCustomer = new javax.swing.JButton();
        btnReloadProduct = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        jButton5.setText("Search");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        txtCustomer_ID.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtCustomer_IDMouseClicked(evt);
            }
        });
        txtCustomer_ID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCustomer_IDActionPerformed(evt);
            }
        });

        txtProduct_Name.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtProduct_NameMouseClicked(evt);
            }
        });

        btnAddCart.setText("Add in Cart");
        btnAddCart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddCartActionPerformed(evt);
            }
        });

        jLabel1.setText("Customer ID");

        jLabel2.setText("Product Name");

        jLabel3.setText("Quantity");

        jLabel4.setText("Product Price");

        jLabel5.setText("Total Price");

        jButton1.setText("Manage Cart");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        btnSearchCustomer.setText("Search");
        btnSearchCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchCustomerActionPerformed(evt);
            }
        });

        btnSearchProduct.setText("Search");
        btnSearchProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchProductActionPerformed(evt);
            }
        });

        CustomerTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Customer ID", "Name", "Email", "Address", "Phone No", "Password"
            }
        ));
        CustomerTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CustomerTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(CustomerTable);

        ProductTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Product ID", "Name", "Category", "Cost", "Price", "Description"
            }
        ));
        ProductTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ProductTableMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(ProductTable);

        btnReloadCustomer.setText("Reload Customer");
        btnReloadCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReloadCustomerActionPerformed(evt);
            }
        });

        btnReloadProduct.setText("Reload Product");
        btnReloadProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReloadProductActionPerformed(evt);
            }
        });

        jButton2.setText("Exit");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(32, 32, 32)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtProductPrice)
                                .addComponent(txtCustomer_ID)
                                .addComponent(txtProduct_Name, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(txtTotalPrice)
                                .addComponent(txt_Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(64, 64, 64)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnAddCart, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 60, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(43, 43, 43)
                                .addComponent(btnReloadCustomer))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(60, 60, 60)
                                .addComponent(btnReloadProduct)))
                        .addGap(233, 233, 233)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnSearchProduct)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtProductName, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnSearchCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtCustomerName, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jScrollPane3))
                .addGap(32, 32, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addGap(43, 43, 43))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(jButton2)
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSearchCustomer)
                    .addComponent(txtCustomerName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnReloadCustomer))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSearchProduct)
                            .addComponent(txtProductName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnReloadProduct))
                        .addGap(30, 30, 30)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(41, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(txtCustomer_ID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel1))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtProduct_Name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2))))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtProductPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtTotalPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(55, 55, 55)
                                .addComponent(jButton1))
                            .addComponent(btnAddCart))
                        .addGap(144, 144, 144))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    OrderOperation orderoperation = new OrderOperation();
    private void btnAddCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddCartActionPerformed

        OrderEntity orderEntity = new OrderEntity();
        orderEntity.setCustomerID(txtCustomer_ID.getText());
        orderEntity.setProductName(txtProduct_Name.getText());
        orderEntity.setProductPrice(txt_Quantity.getText());
        orderEntity.setQuantity(txtProductPrice.getText());
        orderEntity.setTotalprice(txtTotalPrice.getText());

        int OrderIndex = orderoperation.AddOrder(orderEntity);

        if (OrderIndex > 0) {
            try {
                JOptionPane.showMessageDialog(null, "Record Added!");

            } catch (Exception ex) {
                Logger.getLogger(Order.class.getName()).log(Level.SEVERE,null,ex);
            }

        } else {
            JOptionPane.showMessageDialog(null, "Error.");
        }


    }//GEN-LAST:event_btnAddCartActionPerformed

    private void txtCustomer_IDMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtCustomer_IDMouseClicked

        int number = CustomerTable.getSelectedRow();
        txtCustomer_ID.setText(CustomerTable.getValueAt(number, 0).toString());

    }//GEN-LAST:event_txtCustomer_IDMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        try {
            AdminCartManage a = new AdminCartManage();
            a.setVisible(true);
            this.setVisible(false);
        } catch (IOException ex) {
            Logger.getLogger(Order.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtProduct_NameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtProduct_NameMouseClicked
        int number1 = ProductTable.getSelectedRow();
        txtProduct_Name.setText(ProductTable.getValueAt(number1, 1).toString());
        txtProductPrice.setText(ProductTable.getValueAt(number1, 4).toString());
    }//GEN-LAST:event_txtProduct_NameMouseClicked

    private void CustomerTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CustomerTableMouseClicked
        JTable data = (JTable) evt.getSource();
        int row = data.rowAtPoint(evt.getPoint());
        int column = data.columnAtPoint(evt.getPoint());
        txtCustomer_ID.setText(data.getModel().getValueAt(row, 0).toString());
    }//GEN-LAST:event_CustomerTableMouseClicked

    private void ProductTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ProductTableMouseClicked
        JTable data = (JTable) evt.getSource();
        int row = data.rowAtPoint(evt.getPoint());
        int column = data.columnAtPoint(evt.getPoint());
        txtProduct_Name.setText(data.getModel().getValueAt(row, 1).toString());
        txtProductPrice.setText(data.getModel().getValueAt(row, 4).toString());

    }//GEN-LAST:event_ProductTableMouseClicked

    private void btnSearchCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchCustomerActionPerformed

        if (!txtCustomerName.getText().equals("")) {
            CustomerManage target = new CustomerManage();
            String CustomerName = txtCustomerName.getText();
            try {
                DefaultTableModel tableModel = new DefaultTableModel();
                tableModel.addColumn("Customer ID");
                tableModel.addColumn("Name");
                tableModel.addColumn("Email");
                tableModel.addColumn("Address");
                tableModel.addColumn("Phone No");
                tableModel.addColumn("Password");
                List<CustomerEntity> allCustomer = customerManage.GetCustomerByName(CustomerName);
                for (CustomerEntity customerData : allCustomer) {
                    tableModel.addRow(new Object[]{customerData.getCustomerID(), customerData.getCustomerName(), customerData.getEmail(), customerData.getAddress(), customerData.getPhone(), customerData.getPassword()});
                }
                this.CustomerTable.setModel(tableModel);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Fail to loading customer.", "Error", 0);
            }
            // model.getDataVector().removeAllElements();
            //model.addRow(searchtarget);
            //model.fireTableDataChanged();
        } else {
            JOptionPane.showMessageDialog(null, "Please fill in the customer name!");
        }


    }//GEN-LAST:event_btnSearchCustomerActionPerformed

    private void btnSearchProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchProductActionPerformed

        if (!txtProductName.getText().equals("")) {
            ProductManage target = new ProductManage();
            String ProductName = txtProductName.getText();
            try {
                DefaultTableModel tableModel = new DefaultTableModel();
                tableModel.addColumn("Product ID");
                tableModel.addColumn("Name");
                tableModel.addColumn("Category");
                tableModel.addColumn("Cost");
                tableModel.addColumn("Price");
                tableModel.addColumn("Description");
                List<ProductEntity> allProduct = productManage.GetProductByName(ProductName);
                for (ProductEntity productData : allProduct) {
                    tableModel.addRow(new Object[]{productData.getProductID(), productData.getProductName(), productData.getCategory(), productData.getCost(), productData.getPrice(), productData.getDescription()});
                }
                this.ProductTable.setModel(tableModel);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Fail to loading product.", "Error", 0);
            }
            // model.getDataVector().removeAllElements();
            //model.addRow(searchtarget);
            //model.fireTableDataChanged();
        } else {
            JOptionPane.showMessageDialog(null, "Please fill in the product name!");
        }


    }//GEN-LAST:event_btnSearchProductActionPerformed

    private void btnReloadCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReloadCustomerActionPerformed
        try {
            LoadCustomerData();
        } catch (IOException ex) {
            Logger.getLogger(ProductEntry.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnReloadCustomerActionPerformed

    private void btnReloadProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReloadProductActionPerformed
        try {
            LoadProductData();
        } catch (IOException ex) {
            Logger.getLogger(ProductEntry.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnReloadProductActionPerformed

    private void txtCustomer_IDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCustomer_IDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCustomer_IDActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        int n = JOptionPane.showConfirmDialog(null, "Would you like to exit ?", "APU Retail Order Management System", JOptionPane.YES_NO_OPTION);
        if (n == JOptionPane.YES_OPTION) {
            AdminMain a = new AdminMain();
            a.setVisible(true);
            this.setVisible(false);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Order.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Order.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Order.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Order.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Order().setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(Order.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable CustomerTable;
    private javax.swing.JTable ProductTable;
    private javax.swing.JButton btnAddCart;
    private javax.swing.JButton btnReloadCustomer;
    private javax.swing.JButton btnReloadProduct;
    private javax.swing.JButton btnSearchCustomer;
    private javax.swing.JButton btnSearchProduct;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField txtCustomerName;
    private javax.swing.JTextField txtCustomer_ID;
    private javax.swing.JTextField txtProductName;
    private javax.swing.JTextField txtProductPrice;
    private javax.swing.JTextField txtProduct_Name;
    private javax.swing.JTextField txtTotalPrice;
    private javax.swing.JTextField txt_Quantity;
    // End of variables declaration//GEN-END:variables
}
